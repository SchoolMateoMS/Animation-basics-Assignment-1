// drawing basics
// set up canvas and graphics context
let cnv = document.getElementById("myCanvas");
// canvas number 1
let ctx = cnv.getContext("2d");

let image = document.getElementById("cloud")

let RectX2 = 120;

let RectX1 = 120;

let circleY = 300;

let red = 255;

let green = 0;

let blue = 0;

let size = 15;

let frameCount1 = 0;

let frameCount2 = 0;

let frameCount3 = 0;


// canvas 1
cnv.height = 400;
cnv.width = 400;

requestAnimationFrame(background);
function background(){
    ctx.fillStyle = "blue";
    ctx.fillRect(0, 0, cnv.width, cnv.height);
    requestAnimationFrame(background);
}

requestAnimationFrame(ball);
function ball(){
    frameCount1++
    if(frameCount1 < 200){
        circleY -= 1;
        green += 1;
        size += 0.1;
    } else if(frameCount1 >= 200){
        circleY = 300;
        green = 0;
        size = 15;
        frameCount1 = 0;
    }
    ctx.fillStyle = "rgb(" + red + "," + green + "," + blue + ")";
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.arc(200, circleY, size, 0, 2 * Math.PI);
    ctx.fill();
    requestAnimationFrame(ball);
}

requestAnimationFrame(grassf);
function grassf(){
    ctx.fillStyle = "green";
    ctx.fillRect(0, 300, 400, 100);
    requestAnimationFrame(grassf);
}

requestAnimationFrame(cloud2);
function cloud2(){
    frameCount2++
    if(frameCount2 < 200){
        RectX2 -= 1;
    } else if(frameCount2 >= 200){
        RectX2 = 120;
        frameCount2 = 0
    }
    ctx.drawImage(image, RectX2, 120);
    requestAnimationFrame(cloud2);
}

requestAnimationFrame(cloud1);
function cloud1(){
    frameCount3++
    if(frameCount3 < 200){
        RectX1 += 1;
    }else if(frameCount3 >= 200){
        RectX1 = 120;
        frameCount3 = 0
    }
    ctx.drawImage(image, RectX1, 100);
    requestAnimationFrame(cloud1);
}